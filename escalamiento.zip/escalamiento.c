#include <stdio.h>
#include <stdlib.h>
#define ANSI_COLOR_RED "\x1b[31m"
#define ANSI_COLOR_MAGENTA "\x1b[35m"
#define ANSI_COLOR_BLUE "\x1b[34m"
#define ANSI_COLOR_GREEN "\x1b[32m"
#define ANSI_COLOR_YELLOW "\x1b[33m"
#define ANSI_COLOR_RESET "\x1b[0m"

int numC, i, j, k;
float xP, yP;

int llenarMatrices(float A[3][3], float B[3][numC]){
    //Llenado de matriz A=MHS
    for (i=0; i<3; i++){
        for (j=0; j<3; j++){
            A[i][j]=0;
        }
    }
    //definimos el valor de x' y y' en la matriz MHS
    A[0][0]=xP;
    A[1][1]=yP;
    A[2][2]=1;
    //Llenado de matriz B=MHC, ingresamos los valores de x y y del total de pares ordenados
    for (i=0; i<numC; i++){
        for (j=0; j<2; j++){
            if (j==0){            
                printf(ANSI_COLOR_BLUE "Ingrese el valor de x%d: " ANSI_COLOR_RESET, i+1);
            }else{                
                printf(ANSI_COLOR_MAGENTA "Ingrese el valor de y%d: " ANSI_COLOR_RESET, i+1);
            }
            scanf("%f", &B[j][i]);
        }
    }
    //llenado de la ultima fila, la correspondiente a los 1
    for (j=0; j<numC; j++){
        B[2][j]=1;
    }
        return 0;
}

int obtenerCoordenadas(float A[3][3], float B[3][numC], float C[3][numC]){
    //Llenado matriz C= obtener resultados, realizamos la mutiplicacion de matrices
    for (i=0; i<3; i++){
        for (j=0; j<numC; j++){
            C[i][j]=0;
            for(k=0; k<3; k++){
                C[i][j]= (C[i][j]+(A[i][k]*B[k][j]));
            }            
        }
    } 
}

int imprimirMatrices(float A[3][3], float B[3][numC], float C[3][numC]){
    printf("\tMHS\t\t\tMHC\n");
    for (i=0; i<3; i++){
        for (j=0; j<3; j++){
            printf("[%.1f]", A[i][j]);
        }
        printf("\t\t");
        for (j=0; j<numC; j++){
            printf("[%.1f]", B[i][j]);
        }
        printf("\t\t");
        for (j=0; j<numC; j++){
            printf("[%.1f]", C[i][j]);
        }
        printf("\n");
    }
    return 0;
}

int mostrarCoordenadas(float C[3][numC], int numC){ //imprimimos los nuevos pares ordenados
    float x[numC], y[numC];
    for (j=0; j<numC; j++){
        x[j]=C[0][j];
        y[j]=C[1][j];
    }
    printf("\nNuevas coordenadas:\n");
    for (i=0; i<numC; i++){ 
        printf("P%d=(%.1f, %.1f)\n", i+1, x[i], y[i]);
    }
    printf("\n");
    return 0;
}

int main(){
    printf(ANSI_COLOR_YELLOW "Ingrese el numero de pares ordenados: " ANSI_COLOR_RESET);
    scanf("%d", &numC);
    printf(ANSI_COLOR_GREEN "Ingrese el valor de x': " ANSI_COLOR_RESET);  //solicitamos los puntos de escalamiento
    scanf("%f", &xP);
    printf(ANSI_COLOR_GREEN "Ingrese el valor de y': " ANSI_COLOR_RESET);
    scanf("%f", &yP);
    float  A[3][3], B[3][numC], C[3][numC]; //definimos las dimensiones de las matrices
    
    llenarMatrices(A, B);
    obtenerCoordenadas(A, B, C);
    imprimirMatrices(A, B, C);
    mostrarCoordenadas(C, numC);
    system("pause");
    return 0;
}